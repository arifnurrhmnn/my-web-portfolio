export { GlobalStyle } from "./GlobalStyle";
