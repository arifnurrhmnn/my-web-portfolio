"use strict";
(() => {
var exports = {};
exports.id = 512;
exports.ids = [512];
exports.modules = {

/***/ 3110:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ project),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: ./components/Layout/Layout/index.js + 7 modules
var Layout = __webpack_require__(5221);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./Data/data.js
var data = __webpack_require__(6950);
// EXTERNAL MODULE: ./components/Theme/GlobalStyle.js
var GlobalStyle = __webpack_require__(2703);
// EXTERNAL MODULE: external "@iconscout/react-unicons"
var react_unicons_ = __webpack_require__(9632);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
// EXTERNAL MODULE: ./components/Pages/Home/Styles.js
var Styles = __webpack_require__(1973);
;// CONCATENATED MODULE: ./components/Pages/Project/Styles.js


const ProjectSec = external_styled_components_default().div.withConfig({
  displayName: "Styles__ProjectSec",
  componentId: "sc-urhc3v-0"
})(["margin-top:4rem;margin-bottom:4rem;"]);
const ProjectTitle = external_styled_components_default().h1.withConfig({
  displayName: "Styles__ProjectTitle",
  componentId: "sc-urhc3v-1"
})(["margin-bottom:8px;text-align:center;font-size:3.25rem;line-height:1.1;font-weight:600;line-height:60px;color:#f7f8fa;@media screen and (max-width:991px){font-size:2.8rem;line-height:55px;}@media screen and (max-width:575px){font-size:2.4rem;line-height:50px;}"]);
const ProjectSubtitle = external_styled_components_default().p.withConfig({
  displayName: "Styles__ProjectSubtitle",
  componentId: "sc-urhc3v-2"
})(["text-align:center;font-size:1.1rem;font-family:\"Kanit\",serif;"]);
const ProjectRow = external_styled_components_default().div.withConfig({
  displayName: "Styles__ProjectRow",
  componentId: "sc-urhc3v-3"
})(["padding-top:3rem;display:flex;flex-wrap:wrap;flex-direction:row;justify-content:space-between;margin:-1rem;"]);
const ProjectCol = external_styled_components_default().div.withConfig({
  displayName: "Styles__ProjectCol",
  componentId: "sc-urhc3v-4"
})(["padding:2rem;flex-basis:50%;position:relative;filter:grayscale(100%);&:hover{filter:grayscale(0);transition:all 0.3s ease-out;}@media screen and (max-width:767px){flex-basis:100%;}"]);
const ItemImg = external_styled_components_default().div.withConfig({
  displayName: "Styles__ItemImg",
  componentId: "sc-urhc3v-5"
})(["max-width:100%;"]);
const ProjectContent = external_styled_components_default().div.withConfig({
  displayName: "Styles__ProjectContent",
  componentId: "sc-urhc3v-6"
})(["display:flex;flex-wrap:wrap-reverse;flex-direction:row;align-items:center;justify-content:space-between;gap:0.8rem;"]);
const ProjectText = external_styled_components_default().div.withConfig({
  displayName: "Styles__ProjectText",
  componentId: "sc-urhc3v-7"
})(["display:flex;flex-direction:column;"]);
const ItemTitle = external_styled_components_default().h3.withConfig({
  displayName: "Styles__ItemTitle",
  componentId: "sc-urhc3v-8"
})(["font-size:1.25rem;"]);
const ItemSubtitle = external_styled_components_default()(Styles/* ProjectTitle */.vU).withConfig({
  displayName: "Styles__ItemSubtitle",
  componentId: "sc-urhc3v-9"
})(["", " font-weight:500;&:hover{transition:all 0.3s ease-out;color:#818a91;}"], Styles/* ProjectTitle */.vU);
const ItemLink = external_styled_components_default().a.withConfig({
  displayName: "Styles__ItemLink",
  componentId: "sc-urhc3v-10"
})(["display:flex;align-items:center;color:#bfbfbf;margin-right:30px;font-size:16px;font-family:\"Kanit\",serif;cursor:pointer;pointer-events:", ";&:hover{transition:all 0.3s ease-out;color:#818a91;}@media screen and (max-width:575px){font-size:14px;}"], props => props.disabled ? "none" : "painted");
const ProjectTags = external_styled_components_default().div.withConfig({
  displayName: "Styles__ProjectTags",
  componentId: "sc-urhc3v-11"
})(["display:flex;flex-wrap:wrap;gap:0.25rem;"]);
const Tag = external_styled_components_default().span.withConfig({
  displayName: "Styles__Tag",
  componentId: "sc-urhc3v-12"
})(["background-color:#323232;color:#bfbfbf;font-size:0.75rem;border-radius:4px;padding:0 6px;margin-top:0.5rem;"]);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Pages/Project/index.js










function Project(props) {
  const {
    0: disabled,
    1: setDisabled
  } = (0,external_react_.useState)();
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(GlobalStyle/* Container */.W2, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(ProjectSec, {
        children: [/*#__PURE__*/jsx_runtime_.jsx(ProjectTitle, {
          children: "Projects"
        }), /*#__PURE__*/jsx_runtime_.jsx(ProjectSubtitle, {
          children: "Most recent work"
        }), /*#__PURE__*/jsx_runtime_.jsx(ProjectRow, {
          children: data/* DataProjects.map */.rv.map((project, index) => /*#__PURE__*/(0,jsx_runtime_.jsxs)(ProjectCol, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(ItemImg, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: project.imageDisplay,
                width: 362,
                height: 227,
                placeholder: "blur",
                blurDataURL: `${project.imageDisplay}?width=${parseInt(362 * 1 / 100)}&height=${parseInt(227 * 1 / 100)}`,
                layout: "responsive"
              })
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ProjectContent, {
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(ProjectText, {
                children: [/*#__PURE__*/jsx_runtime_.jsx(ItemTitle, {
                  children: project.name
                }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ItemSubtitle, {
                  children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: project.linkGithub,
                    passHref: true,
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(ItemLink, {
                      target: "_blank",
                      disabled: project.linkGithub === "" ? true : false,
                      children: [/*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilGithubAlt, {
                        size: "14",
                        style: {
                          marginRight: "4px"
                        }
                      }), project.textSource]
                    })
                  }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: project.linkSite,
                    passHref: true,
                    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(ItemLink, {
                      target: "_blank",
                      disabled: project.linkSite === "" ? true : false,
                      children: [/*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilLink, {
                        size: "14",
                        style: {
                          marginRight: "4px"
                        }
                      }), project.textLink]
                    })
                  })]
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx(ProjectTags, {
                children: project.tags.map((tag, index) => /*#__PURE__*/jsx_runtime_.jsx(Tag, {
                  children: tag
                }, index))
              })]
            })]
          }, index))
        })]
      })
    })
  });
}
;// CONCATENATED MODULE: ./pages/project.js





function project({
  ProjectLists
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Layout/* default */.Z, {
      title: "Project",
      children: /*#__PURE__*/jsx_runtime_.jsx(Project, {
        DataProjectList: ProjectLists
      })
    })
  });
}
async function getStaticProps() {
  return {
    props: {
      ProjectLists: data/* DataProjects */.rv
    }
  };
}

/***/ }),

/***/ 9632:
/***/ ((module) => {

module.exports = require("@iconscout/react-unicons");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 701:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9914:
/***/ ((module) => {

module.exports = require("styled-components");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [61,649,950,973], () => (__webpack_exec__(3110)));
module.exports = __webpack_exports__;

})();