exports.id = 649;
exports.ids = [649];
exports.modules = {

/***/ 5221:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(701);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/Theme/GlobalStyle.js
var GlobalStyle = __webpack_require__(2703);
;// CONCATENATED MODULE: ./components/Theme/index.js

// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "styled-components"
var external_styled_components_ = __webpack_require__(9914);
var external_styled_components_default = /*#__PURE__*/__webpack_require__.n(external_styled_components_);
;// CONCATENATED MODULE: ./components/Layout/Footer/Styles.js


const Foo = external_styled_components_default().footer.withConfig({
  displayName: "Styles__Foo",
  componentId: "sc-14sgcd6-0"
})(["background-color:#161616;width:100%;display:flex;justify-content:center;align-items:center;font-family:\"Kanit\",serif;left:0;right:0;bottom:0;padding:3rem 0 3rem 0;"]);
const FooterContainer = external_styled_components_default()(GlobalStyle/* Container */.W2).withConfig({
  displayName: "Styles__FooterContainer",
  componentId: "sc-14sgcd6-1"
})(["display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4rem;@media screen and (max-width:575px){flex-flow:column wrap;width:100%;margin-bottom:5rem;}", ""], GlobalStyle/* Container */.W2);
const TextWrapper = external_styled_components_default().div.withConfig({
  displayName: "Styles__TextWrapper",
  componentId: "sc-14sgcd6-2"
})(["display:flex;flex-wrap:wrap;flex-direction:column;justify-content:flex-start;flex:3;@media screen and (max-width:575px){margin-bottom:2rem;}"]);
const FooterTitle = external_styled_components_default().h3.withConfig({
  displayName: "Styles__FooterTitle",
  componentId: "sc-14sgcd6-3"
})(["margin-bottom:12px;font-size:2rem;font-weight:600;color:#f7f8fa;@media screen and (max-width:575px){font-size:1.7rem;}"]);
const FooterSubtitle = external_styled_components_default().p.withConfig({
  displayName: "Styles__FooterSubtitle",
  componentId: "sc-14sgcd6-4"
})(["font-size:1rem;"]);
const EmailLink = external_styled_components_default().a.withConfig({
  displayName: "Styles__EmailLink",
  componentId: "sc-14sgcd6-5"
})(["margin-left:4px;font-weight:400;cursor:pointer;text-decoration:none;&:hover{color:#bfbfbf;text-decoration:underline;}"]);
const LinkWrapper = external_styled_components_default().div.withConfig({
  displayName: "Styles__LinkWrapper",
  componentId: "sc-14sgcd6-6"
})(["padding-top:12px;width:100%;display:flex;justify-content:flex-end;flex:1;gap:1rem;@media screen and (max-width:575px){justify-content:flex-start;}"]);
const SocialLinks = external_styled_components_default().a.withConfig({
  displayName: "Styles__SocialLinks",
  componentId: "sc-14sgcd6-7"
})(["color:#bfbfbf;display:flex;text-decoration:none;&:hover{transition:all 0.3s ease-out;color:#818a91;}"]);
// EXTERNAL MODULE: external "@iconscout/react-unicons"
var react_unicons_ = __webpack_require__(9632);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./components/Layout/Footer/index.js







function Footer() {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Foo, {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterContainer, {
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)(TextWrapper, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(FooterTitle, {
            children: "Get in touch"
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(FooterSubtitle, {
            children: ["For business inquiry please send email to", /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
              href: "mailto:arifnur.rhmnn@gmail.com",
              passHref: true,
              children: /*#__PURE__*/jsx_runtime_.jsx(EmailLink, {
                children: "arifnur.rhmnn@gmail.com"
              })
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(LinkWrapper, {
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://github.com/arifnurrhmnn",
            passHref: true,
            children: /*#__PURE__*/jsx_runtime_.jsx(SocialLinks, {
              children: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilGithub, {
                size: "32"
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://www.linkedin.com/in/arifnurrohman",
            passHref: true,
            children: /*#__PURE__*/jsx_runtime_.jsx(SocialLinks, {
              children: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilLinkedin, {
                size: "32"
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://web.facebook.com/arifnurrhmnn",
            passHref: true,
            children: /*#__PURE__*/jsx_runtime_.jsx(SocialLinks, {
              children: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilFacebook, {
                size: "32"
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://www.instagram.com/arif_pride",
            passHref: true,
            children: /*#__PURE__*/jsx_runtime_.jsx(SocialLinks, {
              children: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilInstagram, {
                size: "32"
              })
            })
          }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "https://wa.me/6281326017533",
            passHref: true,
            children: /*#__PURE__*/jsx_runtime_.jsx(SocialLinks, {
              children: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilWhatsapp, {
                size: "32"
              })
            })
          })]
        })]
      })
    })
  });
}
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
;// CONCATENATED MODULE: ./public/img/logo.png
/* harmony default export */ const logo = ({"src":"/_next/static/image/public/img/logo.49364d120da7a22f45d5b81ad0278dc3.png","height":100,"width":100,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAYAAADED76LAAAA+0lEQVR42iWPMUvDUBhFr5XEWsXWtEIHnQwFRX0IDu2UigpOQkBruwhFm75ACw4Zgl1EMJ06pDEK+ove38kWeLxPXjrfc7gcEBHMr11mxDWBYE2Cl6Q5rwrz12J6w+bCYutpNavxBrXttuo0O2rvuUmldCerLOoMlbgukJTp5OE05yNO49GYzu5ZjmSDim0rbkgsofqvfZr6U+V7vup5PUJsqPLSktjWQAJ1GV3RxJ8o/sLV9fsNaUnLGhBIQecfF/nwaUiDxwG15kc5fozVRev7mMFF5t65FH1GavY2U93bLsFDdvB3yFCkAMxxHBGGoQyCQNr7tgBQZP4DY01tkuiypp8AAAAASUVORK5CYII="});
;// CONCATENATED MODULE: ./components/Navbar/Styles.js



const Nav = external_styled_components_default().nav.withConfig({
  displayName: "Styles__Nav",
  componentId: "sc-1r50g9o-0"
})(["background-color:", ";height:", ";width:100%;display:flex;justify-content:center;align-items:center;font-family:\"Kanit\",serif;font-size:1rem;position:fixed;z-index:999;transition:all 0.5s ease-out;@media screen and (max-width:767px){bottom:0;font-size:1rem;}"], props => props.active ? "#161616" : "transparant", props => props.active ? "4rem" : "5rem");
const NavbarContainer = external_styled_components_default()(GlobalStyle/* Container */.W2).withConfig({
  displayName: "Styles__NavbarContainer",
  componentId: "sc-1r50g9o-1"
})(["display:flex;justify-content:space-between;align-items:center;padding:0 !important;height:100%;", ""], GlobalStyle/* Container */.W2);
const NavLogo = external_styled_components_default().div.withConfig({
  displayName: "Styles__NavLogo",
  componentId: "sc-1r50g9o-2"
})(["font-size:1rem;@media screen and (max-width:767px){display:none;}"]);
const LogoLink = external_styled_components_default().a.withConfig({
  displayName: "Styles__LogoLink",
  componentId: "sc-1r50g9o-3"
})(["display:flex;align-items:center;cursor:pointer;text-decoration:none;color:#fff;"]);
const NavIcon = external_styled_components_default().div.withConfig({
  displayName: "Styles__NavIcon",
  componentId: "sc-1r50g9o-4"
})(["width:30px;height:30px;margin-right:8px;"]);
const NavMenu = external_styled_components_default().ul.withConfig({
  displayName: "Styles__NavMenu",
  componentId: "sc-1r50g9o-5"
})(["display:flex;list-style:none;justify-content:flex-end;height:100%;gap:2.5rem;@media screen and (max-width:767px){gap:1rem;justify-content:space-between;width:100%;position:fixed;left:0;height:5rem;border-radius:1.5rem 1.5rem 0 0;box-shadow:0 -2px 8px 0px #161616;border:1px solid #161616;bottom:0;transition:0.3s;background-color:#201f1f;}"]);
const NavItem = external_styled_components_default().li.withConfig({
  displayName: "Styles__NavItem",
  componentId: "sc-1r50g9o-6"
})(["display:flex;align-items:center;height:100%;@media screen and (max-width:767px){width:calc((100% / 4) - 1rem);display:flex;align-items:center;height:5rem;justify-content:center;&:hover{border:none;}}"]);
const NavLinks = external_styled_components_default().a.withConfig({
  displayName: "Styles__NavLinks",
  componentId: "sc-1r50g9o-7"
})(["border-bottom:", ";color:", ";display:flex;align-items:center;text-decoration:none;height:100%;@media screen and (max-width:767px){text-align:center;align-items:center;height:0;font-weight:", ";border:none;display:table;&:hover{transition:all 0.3s ease;}}"], props => props.isActive ? "2px solid #127419" : "none", props => props.isActive ? "#127419" : "#fff", props => props.isActive ? 600 : 400);
const NavIconMenu = external_styled_components_default().div.withConfig({
  displayName: "Styles__NavIconMenu",
  componentId: "sc-1r50g9o-8"
})(["display:none;@media screen and (max-width:767px){display:flex;justify-content:center;padding-bottom:0.2rem;}"]);
;// CONCATENATED MODULE: ./components/Navbar/index.js









function Navbar() {
  const router = (0,router_.useRouter)();
  const {
    0: click,
    1: seClick
  } = (0,external_react_.useState)(false);
  const {
    0: isActive,
    1: setisActive
  } = (0,external_react_.useState)(true);
  const {
    0: active,
    1: seActive
  } = (0,external_react_.useState)(false);

  const handleClick = () => seClick(!click);

  (0,external_react_.useEffect)(() => {
    const changeBackground = () => {
      if (window.scrollY >= 16) {
        seActive(true);
      } else {
        seActive(false);
      }
    };

    window.addEventListener("scroll", changeBackground);
  });
  const navs = [{
    te: "Home",
    icon: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilEstate, {}),
    href: "/"
  }, {
    te: "About",
    icon: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilUser, {}),
    href: "/about"
  }, {
    te: "Project",
    icon: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilFileAlt, {}),
    href: "/project"
  }, {
    te: "Contact",
    icon: /*#__PURE__*/jsx_runtime_.jsx(react_unicons_.UilBriefcaseAlt, {}),
    href: "/contact"
  }];
  return /*#__PURE__*/jsx_runtime_.jsx(Nav, {
    active: active,
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(NavbarContainer, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(NavLogo, {
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          passHref: true,
          children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(LogoLink, {
            children: [/*#__PURE__*/jsx_runtime_.jsx(NavIcon, {
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: logo
              })
            }), "ARIF"]
          })
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(NavMenu, {
        onClick: handleClick,
        click: click,
        children: navs.map((nav, index) => /*#__PURE__*/jsx_runtime_.jsx(NavItem, {
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: nav.href,
            passHref: true,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)(NavLinks, {
              isActive: router.pathname == nav.href ? isActive : "",
              children: [/*#__PURE__*/jsx_runtime_.jsx(NavIconMenu, {
                children: nav.icon
              }), nav.te]
            })
          })
        }, index))
      })]
    })
  });
}
;// CONCATENATED MODULE: ./components/Layout/Header/index.js




function Header() {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Navbar, {})
  });
}
;// CONCATENATED MODULE: ./components/Layout/Layout/index.js








function Layout(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx((head_default()), {
      children: /*#__PURE__*/jsx_runtime_.jsx("title", {
        children: props.title
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(GlobalStyle/* GlobalStyle */.ZL, {}), /*#__PURE__*/jsx_runtime_.jsx(Header, {}), props.children, /*#__PURE__*/jsx_runtime_.jsx(Footer, {})]
  });
}

/***/ }),

/***/ 2703:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZL": () => (/* binding */ GlobalStyle),
/* harmony export */   "W2": () => (/* binding */ Container),
/* harmony export */   "un": () => (/* binding */ Btn)
/* harmony export */ });
/* unused harmony export InfoSec */
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9914);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);

const GlobalStyle = (0,styled_components__WEBPACK_IMPORTED_MODULE_0__.createGlobalStyle)(["*{box-sizing:border-box;margin:0;padding:0;list-style:none;}body{background-color:#201f1f;color:#bfbfbf;line-height:1.5;font-size:1.1rem;font-family:'Poppins',sans-serif;font-weight:300;}p{color:#bfbfbf;}h1{font-size:calc(1.775rem + 1.5vw);font-weight:300;}h2{font-size:calc(1.325rem + 0.9vw);}strong{font-weight:800}a,h1,h2,h3,h4,h5,h6{color:#fff;font-family:'Kanit',serif;}"]);
const InfoSec = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "GlobalStyle__InfoSec",
  componentId: "sc-1g082ht-0"
})(["color:#fff;padding:5px 0;"]);
const Container = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "GlobalStyle__Container",
  componentId: "sc-1g082ht-1"
})(["z-index:1;width:100%;max-width:1140px;margin-left:auto;margin-right:auto;padding:10px;transition:all 1s;@media screen and (max-width:576px){max-width:100%;}@media screen and (min-width:576px){max-width:540px;}@media screen and (min-width:768px){max-width:720px;}@media screen and (min-width:992px){max-width:960px;}@media screen and (min-width:1200px){max-width:1140px;}"]);
const Btn = styled_components__WEBPACK_IMPORTED_MODULE_0___default().button.withConfig({
  displayName: "GlobalStyle__Btn",
  componentId: "sc-1g082ht-2"
})(["display:flex;align-items:center;gap:6px;white-space:nowrap;border-radius:4px;font-size:0.8rem;font-family:\"Kanit\",serif;cursor:pointer;&:hover{transition:all 0.3s ease-out;}"]);

/***/ }),

/***/ 2431:
/***/ (() => {

/* (ignored) */

/***/ })

};
;