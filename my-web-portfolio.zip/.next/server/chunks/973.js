"use strict";
exports.id = 973;
exports.ids = [973];
exports.modules = {

/***/ 1973:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q$": () => (/* binding */ InfoRow),
/* harmony export */   "Y7": () => (/* binding */ InfoColumn),
/* harmony export */   "OP": () => (/* binding */ TextWrapper),
/* harmony export */   "E3": () => (/* binding */ ImgWrapper),
/* harmony export */   "q0": () => (/* binding */ TopLine),
/* harmony export */   "X6": () => (/* binding */ Heading),
/* harmony export */   "QE": () => (/* binding */ Subtitle),
/* harmony export */   "us": () => (/* binding */ SocialMedia),
/* harmony export */   "WG": () => (/* binding */ SocialLinks),
/* harmony export */   "zx": () => (/* binding */ Button),
/* harmony export */   "sM": () => (/* binding */ DownloadCv),
/* harmony export */   "yD": () => (/* binding */ ProjectsTitle),
/* harmony export */   "ng": () => (/* binding */ ProjectRow),
/* harmony export */   "s_": () => (/* binding */ ProjectCol),
/* harmony export */   "ch": () => (/* binding */ ProjectImg),
/* harmony export */   "Ds": () => (/* binding */ ProjectContent),
/* harmony export */   "vU": () => (/* binding */ ProjectTitle),
/* harmony export */   "Xc": () => (/* binding */ ProjectLink),
/* harmony export */   "v6": () => (/* binding */ ProjectTags),
/* harmony export */   "Vp": () => (/* binding */ Tag),
/* harmony export */   "jL": () => (/* binding */ Banner),
/* harmony export */   "TR": () => (/* binding */ BannerTitle),
/* harmony export */   "N_": () => (/* binding */ BannerButton),
/* harmony export */   "Tr": () => (/* binding */ ButtonLeft),
/* harmony export */   "Hc": () => (/* binding */ ButtonRight),
/* harmony export */   "cS": () => (/* binding */ SkillsTitle),
/* harmony export */   "nA": () => (/* binding */ Skills),
/* harmony export */   "fc": () => (/* binding */ SkillsSlide)
/* harmony export */ });
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9914);
/* harmony import */ var styled_components__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_components__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2703);


const InfoRow = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__InfoRow",
  componentId: "sc-1hlpthi-0"
})(["display:flex;min-height:100vh;margin:0rem -15px 0 -15px;flex-wrap:wrap;align-items:center;flex-direction:row;@media screen and (max-width:767px){flex-direction:column-reverse;}"]);
const InfoColumn = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__InfoColumn",
  componentId: "sc-1hlpthi-1"
})(["padding:15px;flex:1;max-width:50%;flex-basis:50%;@media screen and (max-width:767px){max-width:100%;flex-basis:100%;display:flex;justify-content:center;}"]);
const TextWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__TextWrapper",
  componentId: "sc-1hlpthi-2"
})(["@media screen and (max-width:767px){padding-bottom:65px;}"]);
const ImgWrapper = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ImgWrapper",
  componentId: "sc-1hlpthi-3"
})(["display:flex;justify-content:flex-end;"]);
const TopLine = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h3.withConfig({
  displayName: "Styles__TopLine",
  componentId: "sc-1hlpthi-4"
})(["color:#079211;font-size:1.8rem;font-weight:600;@media screen and (max-width:991px){font-size:1.6rem;}"]);
const Heading = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2.withConfig({
  displayName: "Styles__Heading",
  componentId: "sc-1hlpthi-5"
})(["margin-bottom:24px;font-size:3.25rem;line-height:1.1;font-weight:600;line-height:60px;color:#f7f8fa;@media screen and (max-width:991px){font-size:2.8rem;line-height:55px;}@media screen and (max-width:575px){font-size:2.4rem;line-height:50px;}"]);
const Subtitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default().p.withConfig({
  displayName: "Styles__Subtitle",
  componentId: "sc-1hlpthi-6"
})(["max-width:440px;margin-bottom:35px;font-size:1rem;line-height:30px;color:#bfbfbf;"]);
const SocialMedia = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__SocialMedia",
  componentId: "sc-1hlpthi-7"
})(["width:100%;display:flex;justify-content:flex-start;align-items:center;gap:2rem;@media screen and (max-width:991px){gap:1.5rem;}@media screen and (max-width:575px){gap:1rem;}"]);
const SocialLinks = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "Styles__SocialLinks",
  componentId: "sc-1hlpthi-8"
})(["color:#bfbfbf;display:flex;text-decoration:none;&:hover{transition:all 0.3s ease-out;color:#818a91;}"]);
const Button = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__/* .Btn */ .un).withConfig({
  displayName: "Styles__Button",
  componentId: "sc-1hlpthi-9"
})(["", " margin-right:30px;background:#079211;padding:16px 32px;color:#fff;outline:none;border:none;margin-right:28px;&:hover{background:#127419;box-shadow:0px 10px 13px -10px #000000;}@media screen and (max-width:991px){margin-right:1.4rem;}@media screen and (max-width:575px){margin-right:1rem;}"], _Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__/* .Btn */ .un);
const DownloadCv = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "Styles__DownloadCv",
  componentId: "sc-1hlpthi-10"
})(["display:flex;flex-wrap:nowrap;align-items:center;gap:0.5rem;margin-top:1rem;margin-left:0.4rem;font-size:1rem;"]); // ============== PROJECT ============== //

const ProjectsTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(Heading).withConfig({
  displayName: "Styles__ProjectsTitle",
  componentId: "sc-1hlpthi-11"
})(["", " font-size:3rem;text-align:center;margin-bottom:3rem;@media screen and (max-width:991px){font-size:2.5rem;line-height:55px;}@media screen and (max-width:575px){font-size:2rem;line-height:50px;}"], Heading);
const ProjectRow = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ProjectRow",
  componentId: "sc-1hlpthi-12"
})(["display:flex;flex-wrap:wrap;align-items:center;justify-content:center;flex-direction:column;"]);
const ProjectCol = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ProjectCol",
  componentId: "sc-1hlpthi-13"
})(["max-width:100%;flex-basis:100%;margin-bottom:3rem;filter:grayscale(100%);&:hover{filter:grayscale(0);transition:all 0.3s ease-out;}"]);
const ProjectImg = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ProjectImg",
  componentId: "sc-1hlpthi-14"
})(["width:100%;"]);
const ProjectContent = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ProjectContent",
  componentId: "sc-1hlpthi-15"
})(["display:flex;flex-wrap:wrap-reverse;flex-direction:row;align-items:center;justify-content:space-between;gap:1rem;"]);
const ProjectTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ProjectTitle",
  componentId: "sc-1hlpthi-16"
})(["display:flex;flex-wrap:nowrap;flex-direction:row;align-items:center;"]);
const ProjectLink = styled_components__WEBPACK_IMPORTED_MODULE_0___default().a.withConfig({
  displayName: "Styles__ProjectLink",
  componentId: "sc-1hlpthi-17"
})(["display:flex;align-items:center;color:#bfbfbf;margin-right:30px;font-size:16px;font-family:\"Kanit\",serif;cursor:pointer;pointer-events:", ";&:hover{transition:all 0.3s ease-out;color:#818a91;}@media screen and (max-width:575px){font-size:14px;}"], props => props.disabled ? "none" : "painted");
const ProjectTags = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__ProjectTags",
  componentId: "sc-1hlpthi-18"
})(["display:flex;flex-wrap:wrap;gap:0.25rem;"]);
const Tag = styled_components__WEBPACK_IMPORTED_MODULE_0___default().span.withConfig({
  displayName: "Styles__Tag",
  componentId: "sc-1hlpthi-19"
})(["background-color:#323232;color:#bfbfbf;font-size:0.75rem;border-radius:4px;padding:0 6px;"]);
const Banner = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__Banner",
  componentId: "sc-1hlpthi-20"
})(["display:flex;align-items:center;justify-content:space-between;padding:32px;background-color:#323232;margin-top:1rem;margin-bottom:4rem;@media screen and (max-width:767px){flex-wrap:wrap;flex-direction:row;justify-content:center;}"]);
const BannerTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default().h2.withConfig({
  displayName: "Styles__BannerTitle",
  componentId: "sc-1hlpthi-21"
})(["font-size:24px;@media screen and (max-width:575px){font-size:18px;}@media screen and (max-width:767px){margin-bottom:24px;text-align:center;}@media screen and (max-width:991px){font-size:20px;}"]);
const BannerButton = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__BannerButton",
  componentId: "sc-1hlpthi-22"
})(["display:flex;justify-content:flex-start;"]);
const ButtonLeft = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__/* .Btn */ .un).withConfig({
  displayName: "Styles__ButtonLeft",
  componentId: "sc-1hlpthi-23"
})(["", " margin-right:30px;background:none;padding:16px 32px;color:#fff;outline:none;border:2px solid #079211;margin-right:24px;&:hover{border:2px solid #127419;color:#bfbfbf;box-shadow:0px 10px 13px -10px #000000;}@media screen and (max-width:575px){font-size:12px;margin-right:4px;}@media screen and (max-width:992px){padding:6px 12px;font-size:12px;margin-right:16px;}"], _Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__/* .Btn */ .un);
const ButtonRight = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(_Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__/* .Btn */ .un).withConfig({
  displayName: "Styles__ButtonRight",
  componentId: "sc-1hlpthi-24"
})(["", " margin-right:30px;background:#079211;padding:16px 32px;color:#fff;outline:none;border:none;&:hover{background:#127419;box-shadow:0px 10px 13px -10px #000000;}"], _Theme_GlobalStyle__WEBPACK_IMPORTED_MODULE_1__/* .Btn */ .un);
const SkillsTitle = styled_components__WEBPACK_IMPORTED_MODULE_0___default()(ProjectsTitle).withConfig({
  displayName: "Styles__SkillsTitle",
  componentId: "sc-1hlpthi-25"
})(["", ""], ProjectsTitle);
const Skills = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__Skills",
  componentId: "sc-1hlpthi-26"
})(["display:flex;flex-wrap:wrap;gap:2rem;justify-content:space-around;margin-bottom:4rem;"]);
const SkillsSlide = styled_components__WEBPACK_IMPORTED_MODULE_0___default().div.withConfig({
  displayName: "Styles__SkillsSlide",
  componentId: "sc-1hlpthi-27"
})(["display:flex;justify-content:center;align-items:center;background:#323232;border-radius:10px;max-width:6rem;width:calc((100% / 10) - 1.25rem);@media screen and (max-width:991px){width:calc((100% / 6) - 1.25rem);}"]);

/***/ })

};
;